#!/usr/bin/perl

foreach my $key (sort keys %ENV){
  print "$key value is: $ENV{$key} \n";
}

