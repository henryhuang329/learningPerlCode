#!/usr/bin/perl

@surname = qw \'flintstone', 'rubble', 'flintstone'\;
@name = qw \fred barney wilma\;

$family_name{'fred'} = 'flintstone';
$family_name{'barney'} = 'rubble';
$family_name{'wilma'}  = 'flintstone';

foreach my $person (@name) {
  print "I have heard the person $person : $family_name{$person} \n";
}
