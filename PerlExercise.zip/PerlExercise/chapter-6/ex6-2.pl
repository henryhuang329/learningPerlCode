#!/usr/bin/perl

chomp (@inName = <STDIN>);

foreach my $person ( @inName ) {
  $num{$person} = $num{$person}+1;
}

@array = %num;
print "@array \n";
