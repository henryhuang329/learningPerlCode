#!/usr/bin/perl

sub total{
  my $sum = 0;
  foreach (@_) {
    # print $_;
    $sum = $sum + $_;
  }
  $sum;
}

my @fred = qw (1 3 5 7 9);
my $fredTotal = &total(@fred);
print "The total of \@fread is $fredTotal. \n";
my @fred = 1..1000;
my $fredTotal = &total(@fred);
print "The total of \@fread is $fredTotal. \n";
