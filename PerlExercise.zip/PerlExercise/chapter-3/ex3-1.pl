#!/usr/bin/perl

# chomp (@text = <STDIN>);
@text = <STDIN>;
@text = reverse @text;
print @text;
