#!/usr/bin/perl
print @ARGV;
print reverse <>;
