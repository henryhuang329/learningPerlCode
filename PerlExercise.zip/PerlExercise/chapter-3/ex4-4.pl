#!/usr/bin/perl
# use strict;

@guestName = ();

sub greet {
  my ($name) = @_;
  push @guestName, $name;

  my $guestNum = @guestName;

  if ($guestNum==1) {
     printf "Hi $guestName[0], you are the firet one here!\n";
  }
  else {
    print "Hi $guestName[$guestNun-1], $guestName[$guestNun-2] is also here!\n";
  }  
}

greet ("Fred");
greet ("Barney");
greet ("Henry");

