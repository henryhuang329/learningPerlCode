#!/usr/bin/perl

while (<>) {
  chmop;
  push @A, $_;
}
while (@A>0) {
  $line = pop @A;
  print "$line";
}
