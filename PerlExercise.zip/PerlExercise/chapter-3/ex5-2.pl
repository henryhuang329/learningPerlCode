#!/usr/bin/perl

print "123456789012345678901234567890\n";
while (<>) {
  chomp $_;
  printf "%20s", $_;
}

