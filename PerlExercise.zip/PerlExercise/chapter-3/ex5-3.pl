#!/usr/bin/perl

print "enter align numer:\n";
chomp (my $alignNum = <STDIN>);
print "enter string:\n";
chomp (my @str = <STDIN>);

print "1234567890"x(${alignNum}/10),"\n";
while (@str > 0) {
  printf "%30s\n", $str[0];
  shift @str;
}
