#!/usr/bin/perl

chomp (@number = <STDIN>);
@name = qw/fred betty barney dino wilma pebbles bamm-bamm/;
#print $number[0];
foreach $idx (@number) {
  print $name[$idx],"\n";
}
