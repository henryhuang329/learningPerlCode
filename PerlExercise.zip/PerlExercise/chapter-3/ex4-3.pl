#!/usr/bin/perl
use strict;

sub total{
  my $sum = 0;
  foreach (@_) {
    # print $_;
    $sum = $sum + $_;
  }
  $sum;
}

sub getAvg{
  my $avg = 0;
  my $sum = &total(@_);
  my $num = @_;
  $avg = $sum/$num;
}

sub above_average {
  my @aboveAvg = ();
  my $avg = &getAvg(@_);

  print "avg is: $avg \n";

  foreach (@_) {
    if ($_>$avg) {
      push @aboveAvg, $_;
    }
  }

  @aboveAvg;
}

my @fred = qw (1 3 7 7 9);
my @fredTotal = &above_average(@fred);
print "The total of \@fread is @fredTotal. \n";
