#!/usr/bin/perl
## Copyright (C) 20XX by yours Truly

chomp (@data = <>);

foreach (@data) {

  if (/(.)\1/) {
    print "$_\n";
  }
}
