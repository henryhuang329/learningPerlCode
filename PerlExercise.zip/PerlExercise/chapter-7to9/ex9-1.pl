#!/usr/bin/perl

while (<>) {
  chomp;
  print "Input a name!\n";
  chomp (my $what = <STDIN>);
  if (/($what){3,3}/) {
    print "Matched: |$`<$&>$'|\n";
  } else {
    print "No match: |$_|\n";
  }
}
