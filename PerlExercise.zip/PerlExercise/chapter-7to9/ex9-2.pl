#!/usr/bin/perl

$length = @ARGV;
if ($length!=1) {
  die "ERRON\n";
}

my $file = $ARGV[0];
print "$file\n";

if (! defined $file) {
  die "un-defined input file:$file";
}

my $out = $file;
$out = join ".", $out, "out";
print "out file Name: $out\n";

if (! open $in_fh, '<', $file) {
  die "cannot open $file: $!\n";
}

if (! open $out_fh, '>', $out) {
  die "cannot open $out: $!\n";
}

while (<$in_fh>) {
  s/Fred/Larry/gi;
  print $out_fh $_;
}
