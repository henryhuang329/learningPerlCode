#!/usr/bin/perl

while (<>) {
  chomp;
  if (/\s\z/) {
    print "$_ space!!!\n";
  } else {
    print "No match: |$_|\n";
  }
}
