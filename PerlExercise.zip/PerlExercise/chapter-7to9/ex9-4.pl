#!/usr/bin/perl

$^I = ".bak";

while (<>) {
  if (/\A#!/) {
    $_ .= "## Copyright (C) 20XX by yours Truly\n";
  }
  print ;
}
