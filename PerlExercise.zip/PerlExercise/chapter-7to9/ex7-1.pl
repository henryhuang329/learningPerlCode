#!/usr/bin/perl
## Copyright (C) 20XX by yours Truly

chomp (@data = <>);

foreach (@data) {
  if (/fred/) {
    print "$_\n";
  }
}
