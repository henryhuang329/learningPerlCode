#!/usr/bin/perl

while (<>) {
  chomp;
  if (/\w+a\z/) {
    print "Matched: |$`<$&>$'|\n";
  } else {
    print "No match: |$_|\n";
  }
}
