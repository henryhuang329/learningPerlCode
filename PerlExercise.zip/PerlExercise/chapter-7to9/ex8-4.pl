#!/usr/bin/perl
use 5.010;
while (<>) {
  chomp;
  if (/(?<name1>\b\w*a\b)/) {
    print "\$1 contains '$+{name1}'\n";
    print "Matched: |$`<$&>$'|\n";
  } else {
    print "No match: |$_|\n";
  }
}
