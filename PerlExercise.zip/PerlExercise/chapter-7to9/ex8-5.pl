#!/usr/bin/perl

while (<>) {
  chomp;
  if (/(\b\w*a\b)(.{0,5})/) {
    print "\$1 contains '$1';\$2 contains '$2'\n";
    print "Matched: |$`<$&>$'|\n";
  } else {
    print "No match: |$_|\n";
  }
}
