#!/usr/bin/perl
## Copyright (C) 20XX by yours Truly

chomp (@data = <>);

foreach (@data) {
  if (/[f|F]red/) {
    print "$_\n";
  }
}
