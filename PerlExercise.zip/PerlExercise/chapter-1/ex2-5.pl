#!/usr/bin/perl

print "Input String:\n";
$str0 = <STDIN>;
print "Input repeat Number:\n";
chomp($num1 = <STDIN>);

$output = ${str0}x${num1};
print "${output}\n";
