#!/usr/bin/perl

print "Hello World!\n";
system("echo \"Hello World!\n\"");
