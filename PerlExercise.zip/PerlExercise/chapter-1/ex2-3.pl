#!/usr/bin/perl
print "Input radius:\n";
chomp($radius = <STDIN>);
$pi = 3.141592654;

if ($radius<0) {
	print 0,"\n";
} else {
  print 2*$radius*$pi,"\n"
}
