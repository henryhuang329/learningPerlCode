#!/usr/bin/perl
print "Input radius:\n";
chomp($radius = <STDIN>);
$pi = 3.141592654;

print 2*$radius*$pi,"\n"
