#!/usr/bin/perl
print "Input num0:\n";
chomp($num0 = <STDIN>);
print "Input num1:\n";
chomp($num1 = <STDIN>);

print $num0*$num1,"\n";
