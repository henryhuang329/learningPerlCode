#!/usr/bin/perl
$radius = 12.5;
$pi = 3.141592654;

print 2*$radius*$pi,"\n"
