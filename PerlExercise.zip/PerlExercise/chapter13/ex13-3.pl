#!/usr/bin/perl

print "Enter DIR name:\n";
chomp (my $dir = <STDIN>);
print "Entered Dir: $dir\n ";

opendir my $dh, $dir or die "cannot open:$!";
foreach my $file (sort readdir $dh) {
  print "file: $file\n";
}

die "over!\n";


