#!/usr/bin/perl

print "Enter DIR name:\n";
chomp (my $dir = <STDIN>);
print "Entered Dir: $dir\n ";

if ($dir =~ /\A\s*\Z/) {
  chdir  or die  "cannot enter home root:$!!\n";
} else {
  chdir $dir or die "cannot enter dir because of: $!\n";
}

my @files = <* .*>;
# @files = sort @files;
foreach (@files) {
  print "$_\n"
}
